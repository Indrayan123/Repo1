#!groovy
node(env.nodename){
    stage('SVN Checkout') {
        echo env.svnurl
        checkout([$class: 'SubversionSCM', additionalCredentials: [], excludedCommitMessages: '', excludedRegions: '', excludedRevprop: '', excludedUsers: '', filterChangelog: false, ignoreDirPropChanges: false, includedRegions: '', locations: [[credentialsId: 'SVNUser', depthOption: 'infinity', ignoreExternalsOption: true, local: '.', remote: env.svnurl]], workspaceUpdater: [$class: 'UpdateUpdater']])
    }       
    stage('Get Password') {
	echo "call Shared Library"	
	encpassword=env.weblogicpwd
	connectionpwd = library('Global-Shared-Lib@Branch').sni.GetCredential.decryptPassword(encpassword)
}

    stage('SOA Compile&Deploy') {
	script{
	echo "Running Maven"
    	
    sh ('#!/bin/sh -e\n'+ "/opt/oracle/middleware/oracle_common/modules/org.apache.maven_3.2.5/bin/mvn pre-integration-test -Dsoapassword=${connectionpwd}")
	def DeploymentMsg = load("Jenkins_Script/Deployment_Message.groovy")
    def artifactDetails= "SOA12cMavenAppModules"
	def shellExecutionStatus=DeploymentMsg.logMessage(artifactDetails) 
	echo shellExecutionStatus
	}
}
}