#!groovy

def logMessage(String artifactDetails) {
     script{
    def scriptOp=sh(returnStatus: true, script: "/opt/jenkins/agent/scm/scripts/logDeploymentMessage.sh ${artifactDetails}")
	if (scriptOp==0)
	{
	echo "####Shell script executed successfully####"
	}
	else {
	echo "####Error in Shell script execution####"
	}
}
}
return this;
